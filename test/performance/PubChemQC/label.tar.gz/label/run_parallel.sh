parallel -j4 python ../../grade_label.py {} :::: neutral_label_parallel > LOG.txt
